# DocuMind – Document Q&A Assistant

Upload documents (.txt, .md, .pdf) and ask questions. Answers come only from your files, with the matching source chunks shown and highlighted.

## Features
- Document ingestion with overlapping text chunks
- TF-IDF retrieval (runs fully in the browser, no data leaves your device)
- Chat UI with streaming answers and source citations
- PDF parsing with pdf.js, dark mode, responsive layout

## Run locally
Open `index.html` in a browser. No build step needed.

## Roadmap (full-stack version)
- [ ] FastAPI backend with JWT auth
- [ ] PostgreSQL for users and chat history
- [ ] Embeddings + vector DB (ChromaDB / pgvector)
- [ ] LLM-generated answers grounded in retrieved chunks (RAG)
- [ ] Docker + GitHub Actions CI + deployment

## Tech
HTML, CSS, vanilla JavaScript, pdf.js
